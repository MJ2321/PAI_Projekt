"use client";

import { FormEvent, useState } from "react";
import axios from "axios";
import Select, { SingleValue } from "react-select";
import cities from '@/public/cities';
import makeAnimated from 'react-select/animated';

export default function Form() {
  const input_form = "p-2 border border-white mb-2 outline-none";
  type CityOption = {
    label: string;
    value: string;
  };
  const [selectedCity, setSelectedCity] = useState<CityOption | null>(null);

  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      backgroundColor: '#111', // ciemne tło
      borderColor: 'white',
      color: 'white',
    }),
    singleValue: (provided: any) => ({
      ...provided,
      color: 'white', // wybrana wartość
    }),
    input: (provided: any) => ({
      ...provided,
      color: 'white', // wpisywany tekst
    }),
    placeholder: (provided: any) => ({
      ...provided,
      color: '#aaa', // placeholder
    }),
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isFocused ? '#333' : 'white',
      color: state.isFocused ? 'white' : 'black',
    }),
    menu: (provided: any) => ({
      ...provided,
      zIndex: 9999, // ważne, by nie znikało pod innymi elementami
    }),
  };
  
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const form = e.target as HTMLFormElement;

    const event: any = {};

    console.log(form[5])
    console.dir(form[5])
    event.name = (form[0] as HTMLInputElement).value;
    event.desc = (form[1] as HTMLInputElement).value;
    event.date = (form[2] as HTMLInputElement).value;
    event.url = (form[3] as HTMLInputElement).value;
    event.price = (form[4] as HTMLInputElement).value;
    event.city = selectedCity?.value;

    const res = await axios.post("/api/dashboard/add-event", { event });
  };

  return (
    <div>
      <form className="flex flex-col max-w-[400px] text-white" onSubmit={submit}>
        <input
          type="text"
          placeholder="Nazwa wydarzenia"
          className={input_form}
          required
        />
        <textarea placeholder="Opis" className={input_form} required />
        <input type="date" className={input_form} required />
        <input
          type="text"
          className={input_form}
          required
          placeholder="Link do wydarzenia"
        />
        <input type="text" className={input_form} placeholder="Cena" />
        <Select 
        options={cities}
        components={makeAnimated()}
        isSearchable={true}
        maxMenuHeight={200}
        styles={customStyles}
        onChange={(selectedOption) => {setSelectedCity(selectedOption as CityOption)}}
        ></Select>
        <button
          type="submit"
          className="p-2 cursor-pointer bg-gray-600 hover:bg-gray-700"
        >
          Dodaj
        </button>
      </form>
    </div>
  );
}
