"use client";

import { useState } from "react";

type EventType = {
  name: string;
  desc: string;
  date: string;
  slug: string;
};

type Props = {
  event: EventType;
};

export default function ClientEventPage({ event }: Props) {
  const [formData, setFormData] = useState({
    name: event.name,
    desc: event.desc,
    date: event.date,
  });

  const handleUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      const res = await fetch(`/api/events/${event.slug}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        alert("Event updated successfully!");
        window.location.reload();
      } else {
        console.log("Failed to update event:", res.statusText);
        alert("Failed to update event.");
      }
    } catch (error) {
      console.error("Error updating event:", error);
    }
  };

  return (
    <div>
      <h1>Podstrona Eventu {formData.name}</h1>
      <p>Slug eventu: {event.slug}</p>
      <p>{formData.desc}</p>

      {/* Formularz edycji eventu */}
      <form onSubmit={handleUpdate} className="flex flex-col gap-4 mt-4">
        <label>
          Nazwa:
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="border p-2 rounded"
          />
        </label>
        <label>
          Opis:
          <textarea
            value={formData.desc}
            onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
            className="border p-2 rounded"
          ></textarea>
        </label>
        <label>
          Data:
          <input
            type="date"
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            className="border p-2 rounded"
          />
        </label>
        <button
          type="submit"
          className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
        >
          Zapisz zmiany
        </button>
      </form>
    </div>
  );
}