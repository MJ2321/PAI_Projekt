import Form from "@/components/event/form";
import Link from "next/link";

export default function Events() {
  return (
    <div>
      <div className="mb-4">
        <Link href={"/service/admin"}>&lt; Strona główna</Link>
      </div>
      <div>
        <Form />
      </div>
    </div>
  );
}
