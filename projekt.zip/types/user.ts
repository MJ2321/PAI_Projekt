interface UserI {
  _id?: string;
  name: string;
  email: string;
  password: string;
  admin: boolean;
}

export default UserI;
