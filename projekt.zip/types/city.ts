interface CityI {
    label?: string;
    value: string;
  }
  
  export default CityI;
  